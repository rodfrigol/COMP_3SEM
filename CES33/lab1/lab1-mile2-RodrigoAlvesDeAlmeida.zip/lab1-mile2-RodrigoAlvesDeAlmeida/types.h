#ifndef TYPES_HEADER
#define TYPES_HEADER

/*prints green $ char*/
void print_ms_symbol();

/*prints char** (used in milestone 2)*/
void print_CHARPP(char** c);

/*frees each string of vector*/
void free_CHARPP(char** c);

#endif